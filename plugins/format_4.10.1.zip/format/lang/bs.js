/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'bs', {
	label: 'Format',
	panelTitle: 'Format',
	tag_address: 'Address',
	tag_div: 'Normal (DIV)', // MISSING
	tag_h1: 'Heading 1',
	tag_h2: 'Heading 2',
	tag_h3: 'Heading 3',
	tag_h4: 'Heading 4',
	tag_h5: 'Heading 5',
	tag_h6: 'Heading 6',
	tag_p: 'Normal',
	tag_pre: 'Formatted'
} );
