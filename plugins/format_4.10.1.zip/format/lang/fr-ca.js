/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'fr-ca', {
	label: 'Format',
	panelTitle: 'Format de paragraphe',
	tag_address: 'Adresse',
	tag_div: 'Normal (DIV)',
	tag_h1: 'En-tête 1',
	tag_h2: 'En-tête 2',
	tag_h3: 'En-tête 3',
	tag_h4: 'En-tête 4',
	tag_h5: 'En-tête 5',
	tag_h6: 'En-tête 6',
	tag_p: 'Normal',
	tag_pre: 'Formaté'
} );
