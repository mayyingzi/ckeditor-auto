/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'lv', {
	label: 'Formāts',
	panelTitle: 'Formāts',
	tag_address: 'Adrese',
	tag_div: 'Rindkopa (DIV)',
	tag_h1: 'Virsraksts 1',
	tag_h2: 'Virsraksts 2',
	tag_h3: 'Virsraksts 3',
	tag_h4: 'Virsraksts 4',
	tag_h5: 'Virsraksts 5',
	tag_h6: 'Virsraksts 6',
	tag_p: 'Normāls teksts',
	tag_pre: 'Formatēts teksts'
} );
