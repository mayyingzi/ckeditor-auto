/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'bg', {
	label: 'Формат',
	panelTitle: 'Формат на параграф',
	tag_address: 'Адрес',
	tag_div: 'Нормален (DIV)',
	tag_h1: 'Заглавие 1',
	tag_h2: 'Заглавие 2',
	tag_h3: 'Заглавие 3',
	tag_h4: 'Заглавие 4',
	tag_h5: 'Заглавие 5',
	tag_h6: 'Заглавие 6',
	tag_p: 'Нормален',
	tag_pre: 'Форматиран'
} );
