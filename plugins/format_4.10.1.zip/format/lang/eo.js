/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'eo', {
	label: 'Formato',
	panelTitle: 'ParagrafFormato',
	tag_address: 'Adreso',
	tag_div: 'Normala (DIV)',
	tag_h1: 'Titolo 1',
	tag_h2: 'Titolo 2',
	tag_h3: 'Titolo 3',
	tag_h4: 'Titolo 4',
	tag_h5: 'Titolo 5',
	tag_h6: 'Titolo 6',
	tag_p: 'Normala',
	tag_pre: 'Formatita'
} );
