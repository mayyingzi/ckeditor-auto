/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'sk', {
	label: 'Formát',
	panelTitle: 'Odsek',
	tag_address: 'Adresa',
	tag_div: 'Normálny (DIV)',
	tag_h1: 'Nadpis 1',
	tag_h2: 'Nadpis 2',
	tag_h3: 'Nadpis 3',
	tag_h4: 'Nadpis 4',
	tag_h5: 'Nadpis 5',
	tag_h6: 'Nadpis 6',
	tag_p: 'Normálny',
	tag_pre: 'Formátovaný'
} );
